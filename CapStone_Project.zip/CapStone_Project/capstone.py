#importing libraries
import json
from pyspark.sql.functions import *
from pyspark.sql.types import *
import sqlite3
from pyspark.sql import SparkSession
import xml.etree.ElementTree as ET
import csv
import os
#setting hadoop home environment variable
os.environ['HADOOP_HOME']="C:\\Users\\saranyap\\Downloads\\winutils-master\\winutils-master\\hadoop-3.3.5"

#initiate spark session
spark=SparkSession.builder.appName("CapStoneProject").master("local").config('spark.jars','sqlite-jdbc-3.44.1.0.jar').getOrCreate()
#Creating and inserting data to customers table
db=sqlite3.connect('customers.db')
query="""CREATE TABLE if not exists customers (
  customer_id INTEGER PRIMARY KEY,
  first_name VARCHAR(50),
  last_name VARCHAR(50),
  date_of_birth DATE)"""
db.cursor().execute(query)
count=db.cursor().execute("select * from customers").fetchall()
if count==[]:
    insert_data_query1="""Insert into customers values (1,'John','Doe','1980-05-15 00:00:00.000'),(2,'Jane','Smith','1992-08-21 00:00:00.000'),(3,'Alice','Jhonson','1975-02-10 00:00:00.000'),(4,'Sarah','Jones','1988-12-03 00:00:00.000'),(5,'David','Brown','1995-04-18 00:00:00.000'),(6,'Emma','Miller','1982-07-25 00:00:00.000')"""
    db.cursor().execute(insert_data_query1)
    db.cursor().execute('commit')
db_properties = {"driver":"org.sqlite.JDBC"}
connection_url = "jdbc:sqlite:customers.db"
df_customer=(spark.read.format("jdbc")\
    .option('url',connection_url)\
    .option('driver','org.sqlite.JDBC')\
    .option('query',"select customer_id,first_name,last_name,date_of_birth from customers").load())
df_customer.show()
#Read accounts json file
# Define the schema of the JSON objects
schema = StructType([
    StructField("account_id", StringType()),
    StructField("customer_id", StringType()),
    StructField("employee_id", StringType()),
    StructField("account_type",StringType()),
    StructField("balance",IntegerType())
])
#Converting to simple json file
f = open('accounts.json')
data = json.load(f)
dict_a=[]
with open("out.json", "w") as outfile:
    for i in data['accounts']:
        dict_a.append(i)
    json.dump(dict_a,outfile)
df_accounts=spark.read.json("out.json",schema=schema)
df_accounts.show()
#reading transactions data
df_transactions=spark.read.csv('transactions.csv',header=True)
df_transactions.show()

#reading xml file

tree = ET.parse("employees.xml")
root = tree.getroot()

# Create a CSV file for writing the data
with open("employee.csv", "w") as f:
    writer = csv.writer(f)
    # Write the header row
    writer.writerow(["employee_id", "branch_id", "first_name","last_name","position"])
    # Loop through the XML elements
    for data in root.findall("DATA_RECORD"):
        # Get the attribute and text values
        employee_id = data.find("employee_id").text
        branch_id = data.find("branch_id").text
        first_name = data.find("first_name").text
        last_name=data.find("last_name").text
        position=data.find("position").text
        # Write the data to the CSV file
        writer.writerow([employee_id,branch_id,first_name,last_name,position])
#reading employee data
emp_sch=StructType([StructField('employee_id',StringType()),StructField('branch_id',StringType()),StructField('first_name',StringType()),StructField('last_name',StringType()),StructField('position',StringType())])
df_employees=spark.read.csv('employee.csv',schema=emp_sch,header=True)
df_employees.show()
#reading loans data
df_loans=spark.read.csv('loans.csv',header=True)
df_loans.show()
#reading payments data
df_paymenthist=spark.read.csv('payment_history.csv',header=True)
df_paymenthist.show()
#reading branches data
f = open('branches.json')
data = json.load(f)
dict_a=[]
with open("bout.json", "w") as outfile:
    for i in data['branches']:
        dict_a.append(i)
    json.dump(dict_a,outfile)

df_branches=spark.read.json('bout.json')
df_branches.show()

print("show the balance amount for an account_id = 1:")
df_accounts.select(col('balance')).filter(col('account_id')==1).show()

print("List Transactions for an account_id = 1:")
df_transactions.filter(col('account_id')==1).show()

print('List Accounts with a zero balance:')
df_accounts.filter(col('balance')==0).show()

print('Find the Oldest Customer:')
df_customer.orderBy('date_of_birth').show(1)

print('Calculate the Total Interest Earned Across All Accounts:')
df_loans.withColumn('term',months_between(col('end_date'),col('start_date')))\
.withColumn('tot_int_earned',col('loan_amount')*col('term')*col('interest_rate')).show()

print('List All Accounts with Customer Information:')
df=df_accounts.join(df_customer,on='customer_id',how='inner')
df.show()
print('Calculate Total Balance for Each Customer:')
df.groupBy(col('customer_id'),col('first_name'),col('last_name')).agg(sum(col('balance')).alias('total_balance')).show()
print('Find Customers with Multiple Accounts:')
df.groupBy(col('customer_id')).count().withColumnRenamed('count','num_of_accounts').show()
print('List Transactions with Account and Customer Information')
dff=df_transactions.join(df,on='account_id',how='inner')
dff.show()
print('Calculate Average Transaction Amount')
dff.agg(avg(col('amount')).alias('avg_transaction_amount')).show()
print('Identify High-Value Customers with Total Balance')
dff.groupBy(col('customer_id'),col('first_name'),col('last_name')).agg(sum(col('balance')).alias('total_balance')).show()
print('List Employees and Their Assigned Customers:')
df.join(df_employees,on='employee_id',how='inner').show()
print('Calculate the Total Number of Transactions for Each Account Type:')
df_transactions.join(df_accounts,on='account_id',how='inner').groupby(col('account_type')).count().withColumnRenamed('count','total_no_of_transactions').show()
print('Find Customers with No Transactions:')
df_accounts.join(df_customer,on='customer_id',how='left').join(df_transactions,on='account_id',how='left').filter(col('transaction_id').isNull()).show()
print('Find Customers with No Accounts:')
df_customer.join(df_accounts,on='customer_id',how='left').filter(col('account_id').isNull()).show()
print('List the Latest Transaction for Each Account:')
df_accounts.join(df_transactions,on='account_id',how='inner').groupBy(col('account_id')).agg(max(col('transaction_date')).alias('latest_transaction_date')).show()
print('Calculate the Total Withdrawals for Each Customer:')
dff.groupBy(col('customer_id'),col('first_name'),col('last_name'),col('transaction_type')).agg(sum('amount').alias('total_withdrawals')).filter(col('transaction_type')=='Withdrawal').show()
print('Find Duplicate Transactions:')
dff.groupBy('transaction_id').count().filter(col('count')>1).show()