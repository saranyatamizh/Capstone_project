import json
def read_json(filename,):
    f = open('accounts.json')
    data = json.load(f)
    dict_a=[]
    with open("out.json", "w") as outfile:
        for i in data['accounts']:
            print(type(i))
            dict_a.append(i)
            json.dump(dict_a,outfile)
